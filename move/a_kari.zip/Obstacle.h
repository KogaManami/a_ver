#pragma once
class Obstacle
{
};

